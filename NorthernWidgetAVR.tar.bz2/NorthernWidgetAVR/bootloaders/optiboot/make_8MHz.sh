# https://forum.arduino.cc/index.php?topic=379103.15
#make atmega328 AVR_FREQ=8000000L LED_START_FLASHES=3 BAUD_RATE=57600
make atmega328_8MHz_external_oscillator BAUD_RATE=57600

